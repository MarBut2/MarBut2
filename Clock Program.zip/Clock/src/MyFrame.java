import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MyFrame extends JFrame{
	
	//Calendar calendar;
	SimpleDateFormat timeFormat;
	SimpleDateFormat dayFormat;
	SimpleDateFormat dateFormat;
	JLabel timeLabel; //Displays the time
	JLabel dayLabel; //Displays the day of the week
	JLabel dateLabel; //Display the date
	String time;
	String day;
	String date;
	
	MyFrame(){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("My Clock Program");
		this.setLayout(new FlowLayout());
		this.setSize(350,200); //Size of frame
		this.setResizable(false); //Prevents user from changing the size
		
		timeFormat = new SimpleDateFormat("hh:mm:ss a");
		dayFormat = new SimpleDateFormat("EEEE");
		dateFormat = new SimpleDateFormat("MMMMM dd, yyyy");
		
		timeLabel = new JLabel(); //Displays clock numbers
		timeLabel.setFont(new Font("Digital-7", Font.PLAIN,50));
		timeLabel.setForeground(new Color(0x00FF00)); //Foreground color is green
		timeLabel.setBackground(Color.black); //Background color is black
		timeLabel.setOpaque(true);
		
		dayLabel = new JLabel();
		dayLabel.setFont(new Font("Ink Free", Font.PLAIN,35)); //Text Font for day of the week label
		
		dateLabel = new JLabel();
		dateLabel.setFont(new Font("Ink Free", Font.PLAIN,27));
		
		this.add(timeLabel);
		this.add(dayLabel);
		this.add(dateLabel);
		this.setVisible(true);
		
		setTime();
	}
	
	public void setTime() {
		while(true) {
		time = timeFormat.format(Calendar.getInstance().getTime()); //Obtains the current time
		timeLabel.setText(time);
		
		day = dayFormat.format(Calendar.getInstance().getTime()); //Obtains the current day of the week
		dayLabel.setText(day);
		
		date = dateFormat.format(Calendar.getInstance().getTime()); //Obtains the current day of the week
		dateLabel.setText(date);
		
		try {
		Thread.sleep(1000); //Allows clock to keep updating
	} catch (InterruptedException e) {
		e.printStackTrace();
	}

}

	}
}