import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculator implements ActionListener {
	
	JFrame frame;
	JTextField textfield; //Holds the numbers that are typed as well as the results. Line 17
	JButton[] numberButtons = new JButton[10]; //An array of number calculator buttons
	JButton[] functionButtons = new JButton[9]; //An array of function buttons
	JButton addButton,subButton,multButton,divButton;
	JButton decButton, equButton, delButton, clrButton, negButton;
	JPanel panel; // Declares the calculator Panel to separate buttons
	
	Font myFont = new Font("Lucida Sans Typewriter", Font.BOLD, 19); //Screen Display Font, Bold, and Size 30
	
	double num1 = 0, num2 = 0, result = 0; //Input 1, Input 2, and Result
	char operator;

	Calculator(){
		
		frame = new JFrame("Calculator"); //Initialize new frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Close the program
		frame.setSize(420, 550); //Size of the calculator
		frame.setLayout(null);
		
		textfield = new JTextField();
		textfield.setBounds(50, 25, 300, 50); //Setting the boundaries. X, Y, Width, and Height
		textfield.setFont(myFont);
		textfield.setEditable(false); //Restricts user from typing in the text field
		
		addButton = new JButton("+"); //Adds a function button
		subButton = new JButton("-");
		multButton = new JButton("*");
		divButton = new JButton("/");
		decButton = new JButton(".");
		equButton = new JButton("=");
		delButton = new JButton("Delete");
		clrButton = new JButton("Clear");
		negButton = new JButton("(-)");
		
		functionButtons[0] = addButton;
		functionButtons[1] = subButton;
		functionButtons[2] = multButton;
		functionButtons[3] = divButton;
		functionButtons[4] = decButton;
		functionButtons[5] = equButton;
		functionButtons[6] = delButton;
		functionButtons[7] = clrButton;
		functionButtons[8] = negButton;
		
		for(int i =0; i<9; i++) { //For loop for function buttons
			functionButtons[i].addActionListener(this);
			functionButtons[i].setFont(myFont);
			functionButtons[i].setFocusable(false); //Remove outline around clicked button
		}
		
		for(int i =0; i<10; i++) { //For loop for number buttons
			numberButtons[i] = new JButton(String.valueOf(i));
			numberButtons[i].addActionListener(this);
			numberButtons[i].setFont(myFont);
			numberButtons[i].setFocusable(false); //Remove outline around clicked button
		}
		
		negButton.setBounds(50, 430, 100, 50);
		delButton.setBounds(150, 430, 100, 50);
		clrButton.setBounds(250, 430, 100, 50);
		
		panel = new JPanel(); //Adds panel for number buttons
		panel.setBounds(50, 100, 300, 300);
		panel.setLayout(new GridLayout(4, 4, 10, 10)); //Adds 4 x 4 grid and 10 pixels worth of space in between
		// panel.setBackground(Color.GRAY);
		
		panel.add(numberButtons[1]); //Adds Number Button 1
		panel.add(numberButtons[2]);
		panel.add(numberButtons[3]);
		panel.add(addButton); //Adds the + Button
		panel.add(numberButtons[4]); //Adds Number Button 4
		panel.add(numberButtons[5]);
		panel.add(numberButtons[6]);
		panel.add(subButton); //Adds the - Button
		panel.add(numberButtons[7]); //Adds Number Button 7
		panel.add(numberButtons[8]);
		panel.add(numberButtons[9]);
		panel.add(multButton); //Adds the * Button
		panel.add(decButton);  //Adds the decimal(.) Button
		panel.add(numberButtons[0]); //Adds Number Button 0
		panel.add(equButton); //Adds the  Button
		panel.add(divButton); //Adds the / Button
		
		frame.add(panel); //Adds the grid of numbers to the frame
		frame.add(negButton); //Adds the negative button to the frame
		frame.add(delButton); //Adds the delete button to the frame
		frame.add(clrButton); //Adds the clear button to the frame
		frame.add(textfield);
		frame.setVisible(true);
	}
	public static void main(String[] args) {
		
		Calculator calc = new Calculator();

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		for(int i = 0; i<10; i++)
			if(e.getSource() == numberButtons[i]) { //Adds functionality to the number buttons
				textfield.setText(textfield.getText().concat(String.valueOf(i)));
			}


	if(e.getSource()==decButton) {
		textfield.setText(textfield.getText().concat(".")); //Adds functionality to the decimal button
	}
	if(e.getSource()==addButton) {
		num1 = Double.parseDouble(textfield.getText());
		operator = '+';
		textfield.setText("");

}
	if(e.getSource()==subButton) {
		num1 = Double.parseDouble(textfield.getText());
		operator = '-';
		textfield.setText("");

}
	if(e.getSource()==multButton) {
		num1 = Double.parseDouble(textfield.getText());
		operator = '*';
		textfield.setText("");

}
	if(e.getSource()==divButton) {
		num1 = Double.parseDouble(textfield.getText());
		operator = '/';
		textfield.setText("");
	}
	if(e.getSource()==equButton) {
		num2 =Double.parseDouble(textfield.getText());
		
		switch(operator) {
		case'+':
			result=num1+num2;
			break;
		case'-':
			result=num1-num2;
			break;
		case'*':
			result=num1*num2;
			break;
		case'/':
			result=num1/num2;
			break;
		}
		textfield.setText(String.valueOf(result)); //Shows results of calculations
		num1=result;
	}
	if(e.getSource()==clrButton) {
		textfield.setText(""); //Clears numbers on display screen
	}
	if(e.getSource()==delButton) {
		String string = textfield.getText(); //Deletes numbers on display screen
		textfield.setText("");
		for(int i=0;i<string.length()-1;i++) {
			textfield.setText(textfield.getText()+string.charAt(i));
		}
	}
	if(e.getSource()==negButton) {
		double temp = Double.parseDouble(textfield.getText()); //Temporarily takes whatever value is in the display screen
		temp*=-1; //Changes temporary number to negative
		textfield.setText(String.valueOf(temp));
		}
	}

	}


